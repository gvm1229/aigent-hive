# Team rules
Keep team-note.txt unchanged.

<!-- AIGENT-HIVE:START -->
# Aigent Hive

Project: `phase1-parity`
Profile: `general`
Setup mode: `expedited`
Preference provenance: `global-inherited`
Interface language: `en`
Wiki: `disabled` (backend=`markdown`, language=`both`)
Persona: `balanced`
Primary host: `codex`
Resolved orchestration owner: `host-native`
Resolution evidence: `sha256:0218bcf5a147a6cbfe3f5fb2fd5bea3053db5f99c37abcaf833a27543546a4e2`

## Entry rules

- Read canonical configuration from `.hive/config/harness.toml`.
- Use the selected interface language for questions and responses unless the user explicitly
  requests another language for the current response. Prompt language is a separate current-request
  choice. A message written in another language does not by itself change this preference.
- Unless the user explicitly requests another language for the current prompt, write that prompt in English.
- Preserve user and third-party bytes outside the exact Hive marker and ownership manifest.
- Never call a model-provider API, request provider credentials, or launch a model/subagent process
  on Hive's behalf. The active host owns execution.
- Simple questions use no project edit, plan, or unrelated Skill.

## Conditional routes

Load only the matching contract:

| Work | Contract |
| --- | --- |
| Material work, planning, continuation, closure, host ownership | `.agents/directives/00-project-harness.md` |
| Knowledge lookup, capture, promotion, final memory gate | `.agents/directives/01-project-knowledge.md` |
| Setup, projection refresh, update, migration, rollback | `.agents/directives/02-project-upgrade.md` |
| Automated project edit or concurrent host session | `.agents/directives/03-session-coordination.md` |
| Korean response, Korean document, or Korean rewriting | `.agents/directives/04-korean-language.md` |

- For code edits or documentation restructuring, consult `.hive/directives/00-editing-discipline.md`.
  Reuse unchanged guidance within the task. Its `# CLAUDE.md` heading is original text, not host scope.
- Before an automated edit, reserve exact paths through the session coordination directive.
- Usage guard: disabled by installed preference. Do not invoke a sensor automatically; automatic resume still requires one authorized dispatch brief.
  contract. Exit `0` is only preflight; dispatch still requires one authorized `hive run resume`
  brief. A current-session disable bypasses sensing but never authorizes dispatch.
- On a Wiki-enabled turn, route one bounded lookup before knowledge-dependent work and the
  agent-reviewed memory gate before final response. Wiki disabled means no knowledge mutation.
- Optional Skills and hooks require exact capability and digest approval. Unsupported capability
  remains unsupported; no silent runtime switch or fallback orchestration.
<!-- AIGENT-HIVE:END -->
