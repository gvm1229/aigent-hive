# Existing Claude adapter

<!-- AIGENT-HIVE:START -->
@AGENTS.md
<!-- AIGENT-HIVE:END -->
